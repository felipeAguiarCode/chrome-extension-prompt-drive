// =========================
// API License - (Legacy; premium is now via Stripe)
// =========================

async function activateLicenseKey() {
  return { success: false };
}

Object.assign(api, { activateLicenseKey });
